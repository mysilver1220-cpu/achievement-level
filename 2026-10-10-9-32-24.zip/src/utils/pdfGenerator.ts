import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { AchievementItem, RankGradeItem } from '../types/data';

export interface ChartExportOptions {
  subjectName: string;
  cutoffScore: number;
  containerElement?: HTMLElement | null;
  achievements?: AchievementItem[];
  ranks?: RankGradeItem[];
}

/**
 * Safe round rect helper for Canvas 2D
 */
function drawRoundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  if (typeof ctx.roundRect === 'function') {
    ctx.roundRect(x, y, w, h, r);
  } else {
    ctx.rect(x, y, w, h);
  }
}

/**
 * Robustly rasterizes an SVG element onto a Canvas context or image
 */
async function svgToImage(svgElement: SVGSVGElement): Promise<HTMLImageElement> {
  const clone = svgElement.cloneNode(true) as SVGSVGElement;

  // Ensure required XML namespaces & explicit dimensions
  clone.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
  clone.setAttribute('xmlns:xlink', 'http://www.w3.org/1999/xlink');
  if (!clone.getAttribute('width')) clone.setAttribute('width', '700');
  if (!clone.getAttribute('height')) clone.setAttribute('height', '700');

  const svgString = new XMLSerializer().serializeToString(clone);
  const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
  const URLObj = window.URL || window.webkitURL || window;
  const blobURL = URLObj.createObjectURL(svgBlob);

  return new Promise<HTMLImageElement>((resolve, reject) => {
    const image = new Image();
    const timer = setTimeout(() => {
      URLObj.revokeObjectURL(blobURL);
      reject(new Error('SVG image render timeout'));
    }, 4000);

    image.onload = () => {
      clearTimeout(timer);
      URLObj.revokeObjectURL(blobURL);
      resolve(image);
    };

    image.onerror = (err) => {
      clearTimeout(timer);
      URLObj.revokeObjectURL(blobURL);
      reject(err);
    };

    image.src = blobURL;
  });
}

/**
 * Capture an SVG chart and export as a high-resolution, Korean-compatible executive A4 PDF
 */
export async function exportChartToPDF(
  svgElement: SVGSVGElement,
  fileName: string,
  options: ChartExportOptions
): Promise<void> {
  const { subjectName, cutoffScore, containerElement, achievements, ranks } = options;

  let chartImg: CanvasImageSource | null = null;

  // 1. Try rasterizing SVG directly
  try {
    const img = await svgToImage(svgElement);
    chartImg = img;
  } catch (svgErr) {
    console.warn('Direct SVG rasterization failed, falling back to html2canvas:', svgErr);
    // Fallback: html2canvas on container if available
    if (containerElement) {
      const c = await html2canvas(containerElement, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#FFFFFF',
      });
      chartImg = c;
    } else {
      throw new Error('Unable to render chart to image');
    }
  }

  // 2. Build high-resolution A4 Canvas (A4 ratio 210 x 297 mm, 1400 x 1980 px)
  const a4Canvas = document.createElement('canvas');
  const a4Width = 1400;
  const a4Height = 1980;
  a4Canvas.width = a4Width;
  a4Canvas.height = a4Height;
  const ctx = a4Canvas.getContext('2d');
  if (!ctx) throw new Error('Cannot get canvas context');

  // Background: Crisp Pure/Athletic White
  ctx.fillStyle = '#F8FAFC';
  ctx.fillRect(0, 0, a4Width, a4Height);

  // Top Accent Bar (Nike Stealth Black & Electric Volt)
  ctx.fillStyle = '#000000';
  ctx.fillRect(0, 0, a4Width, 14);
  ctx.fillStyle = '#CCFF00';
  ctx.fillRect(0, 14, a4Width, 5);

  // Header Zone
  const padX = 80;
  let curY = 70;

  // Category Badge (Nike Black + Volt Accent)
  ctx.fillStyle = '#000000';
  ctx.beginPath();
  drawRoundRect(ctx, padX, curY, 140, 32, 6);
  ctx.fill();
  ctx.fillStyle = '#CCFF00';
  ctx.font = 'bold 15px Pretendard, -apple-system, sans-serif';
  ctx.fillText('2028 개정 교육과정', padX + 12, curY + 22);

  // Sub metadata tag
  ctx.fillStyle = '#475569';
  ctx.font = '600 15px Pretendard, -apple-system, sans-serif';
  ctx.fillText('고등학교 1학년 · 동일 모수 N = 352명 · 상대평가 5등급제 연계', padX + 160, curY + 22);

  curY += 60;

  // Main Report Title
  ctx.fillStyle = '#0F172A';
  ctx.font = '900 36px Pretendard, -apple-system, sans-serif';
  ctx.fillText(`${subjectName} 성취도 분포비율 & 5등급제 비교 분석`, padX, curY);

  curY += 34;

  // Subtitle with key metrics
  ctx.fillStyle = '#475569';
  ctx.font = '600 17px Pretendard, -apple-system, sans-serif';
  ctx.fillText(
    `안쪽 성취평가제(A~E) 절대평가 비율과 바깥쪽 5등급제 상대평가 등급컷(${cutoffScore.toFixed(1)}점) 통합 대조 분석`,
    padX,
    curY
  );

  curY += 25;

  // Divider Line
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(padX, curY);
  ctx.lineTo(a4Width - padX, curY);
  ctx.stroke();

  curY += 35;

  // Chart Frame & Card
  const chartCardWidth = a4Width - padX * 2;
  const chartCardHeight = 880;

  ctx.fillStyle = '#FFFFFF';
  ctx.shadowColor = 'rgba(0, 0, 0, 0.08)';
  ctx.shadowBlur = 18;
  ctx.shadowOffsetY = 6;
  ctx.beginPath();
  drawRoundRect(ctx, padX, curY, chartCardWidth, chartCardHeight, 16);
  ctx.fill();
  ctx.shadowColor = 'transparent'; // Reset shadow

  // Subtle border
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1.5;
  ctx.stroke();

  // Draw Chart centered inside the card
  if (chartImg) {
    const chartDrawSize = 780;
    const chartX = padX + (chartCardWidth - chartDrawSize) / 2;
    const chartY = curY + 45;
    ctx.drawImage(chartImg, chartX, chartY, chartDrawSize, chartDrawSize);
  }

  curY += chartCardHeight + 35;

  // Bottom Summary Information Panel (Two Columns)
  const summaryBoxWidth = a4Width - padX * 2;
  const summaryBoxHeight = 270;
  ctx.fillStyle = '#FFFFFF';
  ctx.beginPath();
  drawRoundRect(ctx, padX, curY, summaryBoxWidth, summaryBoxHeight, 14);
  ctx.fill();
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1;
  ctx.stroke();

  // Left Column: 성취평가제 핵심 요약 (Nike Racer Blue)
  const col1X = padX + 30;
  let colY = curY + 40;
  ctx.fillStyle = '#0055FE';
  ctx.font = 'bold 18px Pretendard, -apple-system, sans-serif';
  ctx.fillText('● 성취평가제 (A~E) 성적 분포', col1X, colY);

  colY += 28;
  ctx.font = '500 15px Pretendard, -apple-system, sans-serif';
  ctx.fillStyle = '#334155';
  if (achievements && achievements.length > 0) {
    const achText = achievements.map((a) => `${a.grade}: ${a.ratio}%`).join('  |  ');
    ctx.fillText(achText, col1X, colY);
  } else {
    ctx.fillText('A등급: 23.6%  |  B등급: 30.1%  |  C등급: 16.5%  |  D등급: 15.3%  |  E(미도달): 14.5%', col1X, colY);
  }

  colY += 32;
  ctx.fillStyle = '#64748B';
  ctx.font = '14px Pretendard, -apple-system, sans-serif';
  ctx.fillText('※ A등급 비율(23.6%)이 1등급 기준(10.0%)보다 2.36배 넓어 A등급 착시 현상 주의 요망', col1X, colY);

  // Right Column: 5등급제 등급컷 요약 (Nike Total Infrared)
  const col2X = padX + summaryBoxWidth / 2 + 10;
  let col2Y = curY + 40;
  ctx.fillStyle = '#FF4D26';
  ctx.font = 'bold 18px Pretendard, -apple-system, sans-serif';
  ctx.fillText('● 2028 5등급제 등급컷 기준', col2X, col2Y);

  col2Y += 28;
  ctx.font = '500 15px Pretendard, -apple-system, sans-serif';
  ctx.fillStyle = '#334155';
  if (ranks && ranks.length > 0) {
    const rankText = ranks.slice(0, 3).map((r) => `${r.rankName}: 컷 ${r.cutoffScore.toFixed(1)}점`).join('  |  ');
    ctx.fillText(rankText, col2X, col2Y);
    col2Y += 26;
    const rankText2 = ranks.slice(3).map((r) => `${r.rankName}: 컷 ${r.cutoffScore.toFixed(1)}점`).join('  |  ');
    ctx.fillText(rankText2, col2X, col2Y);
  } else {
    ctx.fillText(`1등급: 컷 ${cutoffScore.toFixed(1)}점  |  2등급: 컷 87.0점  |  3등급: 컷 72.0점`, col2X, col2Y);
    col2Y += 26;
    ctx.fillText('4등급: 컷 56.0점  |  5등급: 컷 47.0점', col2X, col2Y);
  }

  col2Y += 30;
  ctx.fillStyle = '#64748B';
  ctx.font = '14px Pretendard, -apple-system, sans-serif';
  ctx.fillText(`※ 1등급 산출 비율: 9.9% (상위 10% 기준 충족, 컷 ${cutoffScore.toFixed(1)}점)`, col2X, col2Y);

  // Footer
  const footerY = a4Height - 45;
  ctx.strokeStyle = '#E2E8F0';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padX, footerY - 20);
  ctx.lineTo(a4Width - padX, footerY - 20);
  ctx.stroke();

  ctx.fillStyle = '#64748B';
  ctx.font = '13px Pretendard, -apple-system, sans-serif';
  ctx.fillText('2028 Academic Achievement & 5-Tier Grade Evaluation Dashboard · Nike Dynamic Edition', padX, footerY);
  ctx.fillText(new Date().toLocaleDateString('ko-KR') + ' 발행', a4Width - padX - 110, footerY);

  // 3. Convert Canvas to PDF
  const imgData = a4Canvas.toDataURL('image/png');
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  pdf.addImage(imgData, 'PNG', 0, 0, 210, 297, undefined, 'FAST');
  const safeFileName = fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`;
  pdf.save(safeFileName);
}

/**
 * Capture any HTML element (e.g. 6-subject gallery, matrix, or report) and download as a high-quality A4 PDF
 */
export async function exportElementToPDF(
  element: HTMLElement,
  fileName: string,
  title?: string
): Promise<void> {
  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    logging: false,
    backgroundColor: '#FAF9F6',
    windowWidth: element.scrollWidth,
  });

  const imgData = canvas.toDataURL('image/png');
  const pdf = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
    compress: true,
  });

  const pageWidth = 210;
  const pageHeight = 297;
  const margin = 8;
  const contentWidth = pageWidth - margin * 2;
  const contentHeight = (canvas.height * contentWidth) / canvas.width;

  let heightLeft = contentHeight;
  let position = margin;

  pdf.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
  heightLeft -= pageHeight - margin * 2;

  while (heightLeft > 0) {
    position = heightLeft - contentHeight + margin;
    pdf.addPage();
    pdf.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
    heightLeft -= pageHeight - margin * 2;
  }

  const safeFileName = fileName.endsWith('.pdf') ? fileName : `${fileName}.pdf`;
  pdf.save(safeFileName);
}
