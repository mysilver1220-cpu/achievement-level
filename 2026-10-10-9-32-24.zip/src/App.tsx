/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { allSubjectsData } from './data/allSubjectsData';
import { SubjectData, AchievementItem, RankGradeItem } from './types/data';
import { NestedDonutChart } from './components/NestedDonutChart';
import { SixSubjectsDonutGallery } from './components/SixSubjectsDonutGallery';
import { SubjectInputTable } from './components/SubjectInputTable';
import { exportElementToPDF } from './utils/pdfGenerator';
import {
  Printer,
  Share2,
  Check,
  Layers,
  FileText,
} from 'lucide-react';

export default function App() {
  const [semester, setSemester] = useState<1 | 2>(1);
  const [selectedSubjectId, setSelectedSubjectId] = useState<string>('korean-1'); // 'all' or subject id
  const [allSubjects, setAllSubjects] = useState<SubjectData[]>(allSubjectsData);

  const [selectedSegment, setSelectedSegment] = useState<{
    type: 'rank' | 'achievement';
    id: string;
  } | null>(null);

  const [shareCopied, setShareCopied] = useState(false);
  const [isGlobalExporting, setIsGlobalExporting] = useState(false);
  const [globalDownloadSuccess, setGlobalDownloadSuccess] = useState<string | null>(null);

  // Filter subjects by current active semester
  const currentSemesterSubjects = allSubjects.filter((s) => s.semester === semester);

  // Active subject for single view
  const activeSubject =
    currentSemesterSubjects.find((s) => s.id === selectedSubjectId) ||
    currentSemesterSubjects[0] ||
    allSubjects[0];

  const handleSemesterChange = (newSemester: 1 | 2) => {
    setSemester(newSemester);
    if (selectedSubjectId !== 'all') {
      const defaultSub = allSubjects.find(
        (s) => s.semester === newSemester && s.category === activeSubject.category
      ) || allSubjects.find((s) => s.semester === newSemester);
      if (defaultSub) setSelectedSubjectId(defaultSub.id);
    }
  };

  const handleUpdateCurrentAchievements = (newAch: AchievementItem[]) => {
    setAllSubjects((prev) =>
      prev.map((sub) => (sub.id === activeSubject.id ? { ...sub, achievements: newAch } : sub))
    );
  };

  const handleUpdateCurrentRanks = (newRanks: RankGradeItem[]) => {
    setAllSubjects((prev) =>
      prev.map((sub) => (sub.id === activeSubject.id ? { ...sub, ranks: newRanks } : sub))
    );
  };

  const handleResetCurrentSubject = () => {
    const original = allSubjectsData.find((s) => s.id === activeSubject.id);
    if (!original) return;
    setAllSubjects((prev) =>
      prev.map((sub) => (sub.id === activeSubject.id ? { ...original } : sub))
    );
  };

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadHeaderPDF = async () => {
    const reportElem = document.getElementById('report-main-content');
    if (!reportElem) return;
    setIsGlobalExporting(true);
    try {
      const fileName =
        selectedSubjectId === 'all'
          ? `${semester}학기_6개과목_성취도_5등급제_통합비교.pdf`
          : `${activeSubject.name}_성취도분포비율_리포트.pdf`;
      await exportElementToPDF(reportElem, fileName);
      setGlobalDownloadSuccess(fileName);
      setTimeout(() => setGlobalDownloadSuccess(null), 5000);
    } catch (err) {
      console.error('Global PDF export failed', err);
    } finally {
      setIsGlobalExporting(false);
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setShareCopied(true);
    setTimeout(() => setShareCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans">
      {/* Top Header: 단순하고 명확한 제목 */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-30 shadow-2xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-15 flex items-center justify-between gap-4">
          {/* Main Title: 1. 제목 - 성취도 분포비율 vs 등급 비교 */}
          <div className="flex items-center gap-3">
            <h1 className="text-lg sm:text-xl font-black tracking-tight text-slate-950 whitespace-nowrap">
              성취도 분포비율 vs 등급 비교
            </h1>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleDownloadHeaderPDF}
              disabled={isGlobalExporting}
              className="px-3 py-1.5 text-xs font-bold text-white bg-[#922B48] hover:bg-[#791E38] rounded-lg transition-all flex items-center gap-1.5 shadow-xs border border-red-950/20 cursor-pointer disabled:opacity-60 active:scale-95"
              title="현재 화면을 PDF 파일로 다운로드"
            >
              <FileText className="w-4 h-4 text-amber-200" />
              <span>{isGlobalExporting ? '변환 중...' : 'PDF 다운로드'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="p-1.5 sm:px-2.5 sm:py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-300 rounded-lg hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer"
              title="브라우저 인쇄"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden md:inline">인쇄</span>
            </button>

            <button
              onClick={handleShare}
              className="px-3 py-1.5 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-300 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              {shareCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4 text-slate-500" />}
              <span className="hidden sm:inline">{shareCopied ? '복사됨' : '공유'}</span>
            </button>
          </div>
        </div>

        {/* 4. 1학기 과목과 2학기 과목 구분 탭 + 5. 과목 통합 비교 탭 & 과목 선택 탭 */}
        <div className="bg-[#FAF8F5] border-t border-slate-200 px-4 sm:px-6 lg:px-8 py-2 overflow-x-auto scrollbar-none">
          <div className="max-w-7xl mx-auto flex items-center gap-3">
            {/* 학기 선택 탭 (1학기 vs 2학기) */}
            <div className="flex items-center bg-white p-0.5 rounded-lg border border-slate-300 shrink-0">
              <button
                onClick={() => handleSemesterChange(1)}
                className={`px-3 py-1 text-xs font-black rounded-md transition-all cursor-pointer ${
                  semester === 1
                    ? 'bg-[#245882] text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                1학기
              </button>
              <button
                onClick={() => handleSemesterChange(2)}
                className={`px-3 py-1 text-xs font-black rounded-md transition-all cursor-pointer ${
                  semester === 2
                    ? 'bg-[#245882] text-white shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                2학기
              </button>
            </div>

            <span className="text-slate-300">|</span>

            {/* 과목 통합 비교 탭 */}
            <button
              onClick={() => setSelectedSubjectId('all')}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-black rounded-lg transition-all whitespace-nowrap cursor-pointer shrink-0 shadow-2xs ${
                selectedSubjectId === 'all'
                  ? 'bg-slate-950 text-white border border-slate-950'
                  : 'bg-white text-slate-800 border border-slate-300 hover:bg-slate-100'
              }`}
            >
              <Layers className="w-3.5 h-3.5 text-amber-300" />
              <span>{semester}학기 6개 과목 통합 비교</span>
            </button>

            <span className="text-slate-300">|</span>

            {/* 개별 과목 선택 탭 (8. 오직 과목명만 표시) */}
            <div className="flex items-center gap-1.5 shrink-0">
              {currentSemesterSubjects.map((sub) => {
                const isSelected = selectedSubjectId === sub.id;
                return (
                  <button
                    key={sub.id}
                    onClick={() => setSelectedSubjectId(sub.id)}
                    className={`px-3 py-1.5 text-xs font-black rounded-lg transition-all whitespace-nowrap cursor-pointer ${
                      isSelected
                        ? 'bg-[#245882] text-white shadow-xs'
                        : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    {sub.name}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </header>

      {/* Global Download Feedback Banner */}
      {globalDownloadSuccess && (
        <div className="bg-emerald-50 border-b border-emerald-200 px-4 py-2 text-xs text-emerald-900 shadow-2xs">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
            <span className="font-semibold flex items-center gap-1.5">
              <Check className="w-4 h-4 text-emerald-600" />
              <span>
                <strong>[{globalDownloadSuccess}]</strong> 파일이 PC의 기본 <strong>'다운로드(Downloads)'</strong> 폴더에 저장되었습니다.
              </span>
            </span>
            <button
              onClick={() => setGlobalDownloadSuccess(null)}
              className="text-emerald-700 hover:text-emerald-950 font-bold px-2 py-0.5 rounded cursor-pointer"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Workspace (부장이 한눈에 보기 쉽게 단순하고 직관적인 구성) */}
      <main id="report-main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-5 space-y-5">
        {/* ======================================================== */}
        {/* CASE 1: 6개 과목 학기별 통합 비교 뷰 (동심원 파이 3x2 PPT 최적) */}
        {/* ======================================================== */}
        {selectedSubjectId === 'all' && (
          <SixSubjectsDonutGallery
            subjects={currentSemesterSubjects}
            onSelectSubject={setSelectedSubjectId}
            semesterTitle={`${semester}학기 6개 과목 성취도 vs 등급 통합 비교`}
          />
        )}

        {/* ======================================================== */}
        {/* CASE 2: 단일 과목 뷰 (직접 입력 표 + 동심원 파이 차트) */}
        {/* ======================================================== */}
        {selectedSubjectId !== 'all' && (
          <div className="space-y-4">
            {/* 15, 16, 17. 성취도별 비율과 등급별 컷 점수 직접 입력 표 (실시간 동시 반영) */}
            <SubjectInputTable
              subject={activeSubject}
              onUpdateAchievements={handleUpdateCurrentAchievements}
              onUpdateRanks={handleUpdateCurrentRanks}
              onReset={handleResetCurrentSubject}
            />

            {/* 6, 7, 9, 10, 11. 동심원 파이 차트 (원형 텍스트, 큰 A~E 비율, 가운데 과목명만) */}
            <div className="bg-white border border-slate-200 rounded-xl p-5 shadow-xs flex flex-col items-center">
              <div className="w-full flex items-center justify-between mb-2">
                <h2 className="text-base font-black text-slate-900">
                  {activeSubject.name}
                </h2>
              </div>

              <NestedDonutChart
                achievements={activeSubject.achievements}
                ranks={activeSubject.ranks}
                totalStudents={activeSubject.totalStudents}
                selectedSegment={selectedSegment}
                onSelectSegment={setSelectedSegment}
                subjectName={activeSubject.name}
                cutoffScore={activeSubject.ranks[0].cutoffScore}
              />
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
